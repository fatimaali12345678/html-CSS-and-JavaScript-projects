const petFace = document.getElementById('petFace');
const message = document.getElementById('message');

document.getElementById('feedBtn').addEventListener('click', () => {
  petFace.textContent = '😋';
  message.textContent = "Yummy! Thank you for the carrot! 🥕";
});

document.getElementById('playBtn').addEventListener('click', () => {
  petFace.textContent = '😁';
  message.textContent = "Yay! I love playing with you! 🎾";
});

document.getElementById('sleepBtn').addEventListener('click', () => {
  petFace.textContent = '😴';
  message.textContent = "Zzz... Goodnight! 🌙💤";
});
