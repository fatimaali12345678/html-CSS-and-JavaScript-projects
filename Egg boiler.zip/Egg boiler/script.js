const startBtn = document.querySelector('button');
const timerDisplay = document.querySelector('.timer-display');
const minutesInput = document.getElementById('minutes');

let countdown;

startBtn.addEventListener('click', () => {
  let minutes = parseInt(minutesInput.value);
  if (isNaN(minutes) || minutes <= 0) {
    alert("Please enter a valid number of minutes!");
    return;
  }

  let time = minutes * 60;
  updateDisplay(time);

  clearInterval(countdown);

  countdown = setInterval(() => {
    time--;
    updateDisplay(time);

    if (time <= 0) {
      clearInterval(countdown);
      alert("🐣 Ding! Your egg is ready!");
    }
  }, 1000);
});

function updateDisplay(seconds) {
  let min = Math.floor(seconds / 60);
  let sec = seconds % 60;
  timerDisplay.textContent = `${pad(min)}:${pad(sec)}`;
}

function pad(num) {
  return num < 10 ? '0' + num : num;
}
